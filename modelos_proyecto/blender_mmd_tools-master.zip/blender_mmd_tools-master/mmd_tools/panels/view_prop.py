# -*- coding: utf-8 -*-

from bpy.types import Panel

import mmd_tools.core.model as mmd_model

class _PanelBase(object):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

class MMDModelObjectDisplayPanel(_PanelBase, Panel):
    bl_idname = 'OBJECT_PT_mmd_tools_root_object_display'
    bl_label = 'MMD Display'

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None:
            return False

        root = mmd_model.Model.findRoot(obj)
        if root is None:
            return False

        return True

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        root = mmd_model.Model.findRoot(obj)

        row = layout.row(align=True)
        c = row.column(align=True)
        c.prop(root.mmd_root, 'show_meshes', text='Mesh')
        c.prop(root.mmd_root, 'show_armature', text='Armature')
        c.prop(root.mmd_root, 'show_rigid_bodies', text='Rigidbody')
        c.prop(root.mmd_root, 'show_joints', text='Joint')
        c = row.column(align=True)
        c.prop(root.mmd_root, 'show_temporary_objects', text='Temporary Object')
        c.prop(root.mmd_root, 'show_names_of_rigid_bodies', text='Rigidbody Name')
        c.prop(root.mmd_root, 'show_names_of_joints', text='Joint Name')


class MMDViewPanel(_PanelBase, Panel):
    bl_idname = 'OBJECT_PT_mmd_tools_view'
    bl_label = 'MMD Shading'

    def draw(self, context):
        layout = self.layout

        col = layout.column()
        c = col.column(align=True)
        r = c.row(align=True)
        r.operator('mmd_tools.set_glsl_shading', text='GLSL')
        r.operator('mmd_tools.set_shadeless_glsl_shading', text='Shadeless')
        r = c.row(align=True)
        r.operator('mmd_tools.reset_shading', text='Reset')
